package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.HomePage;
import Pages.Menu;
import Pages.Cart;
import Pages.Order;


public class HomeTC1 {

	public static void main(String[] args) throws InterruptedException {		
		System.setProperty("webdriver.chrome.driver", "---Exact path to chromedriver.exe---");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.demoblaze.com/prod.html?idp_=1");
		
		
		HomePage home = new HomePage(driver);
		Menu menu = new Menu(driver);
		Cart cart = new Cart(driver);
		Order order = new Order(driver);
		
		
		home.clickLogin();
		menu.clickCart();
		cart.clickOrder();
		
		order.enterUsername("Cristina");
		order.enterCountry("Ecuador");
		order.enterCity("Quito");
		order.enterCard("101056888");
		order.enterMonth("1");
		order.enterYear("2025");
		
		order.clickPurchase();
		
		Thread.sleep(6000);
		
		order.clickConfirm();
		
		
		System.out.println("The page heading is --- "+menu.getHeading() );
		
        driver.quit();

	}

}
