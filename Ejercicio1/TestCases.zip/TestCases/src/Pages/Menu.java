package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Menu {
	WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Menu(WebDriver driver) {
		this.driver=driver;
	}
	
	
	
	By cart = By.id("cartur");
	By price = By.className("price-container");
	
	
	
	//Method to click on Logout button
	public void clickCart() {
		driver.findElement(cart).click();
	}
	public String getHeading() {
		String head = driver.findElement(price).getText();
		return head;
	}

}
