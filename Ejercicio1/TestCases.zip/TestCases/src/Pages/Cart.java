package Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Cart {
	
	WebDriver driver;
		
	
	public Cart(WebDriver driver) {
		this.driver=driver;
	}
	By BuyBtn = By.className("btn btn-success");
	
	
	public void clickOrder()  {	
		driver.findElement(BuyBtn).click();	
	}
	
	

}
