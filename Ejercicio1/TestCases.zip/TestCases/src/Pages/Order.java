package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Order {
	WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Order(WebDriver driver) {
          this.driver = driver;
	}
	
	
		By name = By.id("name");
		By countries = By.id("country");
		By cities = By.id("city");
		By cards = By.id("card");
		By months = By.id("month");
		By years = By.id("year");
		
		
		By purchaseBtn = By.className("btn btn-primary");
		
		By confirmBtn = By.className("confirm");
		
		
	
		public void enterUsername(String user) {
			driver.findElement(name).sendKeys(user);
		}

	
		public void enterCountry(String country) {
			driver.findElement(countries).sendKeys(country);
		}
		
		public void enterCity(String city) {
			driver.findElement(cities).sendKeys(city);
		}
		
		public void enterCard(String card) {
			driver.findElement(cards).sendKeys(card);
		}
		
		public void enterMonth(String month) {
			driver.findElement(months).sendKeys(month);
		}
		
		public void enterYear(String year) {
			driver.findElement(years).sendKeys(year);
		}
		
		
		//Method to click on Login button
		public void clickPurchase() {
			driver.findElement(purchaseBtn).click();
		}
		
		public void clickConfirm() {
			driver.findElement(confirmBtn).click();
		}

}
