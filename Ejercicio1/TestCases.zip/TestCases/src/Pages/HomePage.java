package Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class HomePage {
	WebDriver driver;
	Actions builder = new Actions(driver);
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	By AddBtn = By.id("btn btn-success btn-lg");
	
	//Method to click login button
	public void clickLogin()  {
		//driver.findElements(By.className("hrefch")).get(0).click();
		driver.findElement(AddBtn).click();
		Actions typeInCAPS = builder.sendKeys(Keys.ESCAPE);
		typeInCAPS.perform();

	}
	

}
